#' Physical Activity Summary-Summations
#'
#' Summarize activity measures
#' @param final.dat cleaned final data that is between record getup time and sleep time
#' @return hours.worn.total Total worn hours
#' @return sed.hour  Total sedantary hours
#' @return stand.hour Total stand hours
#' @return step.hour Total step hours
#' @return num.changes.from.sed.to.non.sed Numbers of changing from sedantary to non sadantary status
#' @return step.count.total Total step count
#' @return gini.index   Gini index of sedentary
#' @return num.hour.over.3.METs Number of hours that Metabolic Equivalent of Task (MET) is over 3
#' @return MET.hours  Total METs
#' @return table A table that shows all above results
#' @details All numbers are calculated in the given time period (day, hour, etc.). Total sedentary/standing/stepping hours are obtained from the summation of the duration times for sedentary/standing/stepping activities in the given time period. To calculate gini index, all of the recorded sedentary durations are listed and the \emph{gini} function in the R package \pkg{reldist} is used.

#' @examples  data(sampledata);PA_summary(sampledata)
#' @export
PA_summary=function (final.dat) {
  library(reldist)

  dat=final.dat
  if(is.numeric(dat$Time)==F) ####if  is.numeric(dat$Time)==F, we need further modification of time in next step
  {
    ee<-as.character(dat$Time)
    max.length<-max(nchar(ee))
    ee[nchar(ee)!=max.length]<-"#1899-12-30 00:00:00#"
    #### use character type, may not be good
    ee.new<- (as.numeric( as.POSIXlt( substr(ee, 2, max.length-1 )  )    )+2209190400)/24/60/60
    #### use interval type, this is the best
    start.ee<-  min(which(dat[,2]>0))-1
    if (start.ee>1)
    {
      ee.new.int.type <-c( ee.new[1:((start.ee)-1)],ee.new[start.ee]+(dat$DataCount[start.ee:nrow(dat)]/10/24/60/60)  )
    }else
    {    ee.new.int.type <-ee.new[start.ee]+(dat$DataCount[start.ee:nrow(dat)]/10/24/60/60)
    } #### if interval type has large difference with character type, use character type
    int.dif.char<-which(abs(ee.new-ee.new.int.type)>0.1 )
    ee.new.int.type[int.dif.char]<-ee.new[int.dif.char]
    ####
    dat<-cbind(ee.new.int.type,dat[,2:6])
  }
  final.dat<-dat[,c(1,3,4,6)]
  colnames(final.dat)<-c("date.time","Interval","ActivityCode", "METs")
  final.dat=subset(final.dat,date.time!=0.625) #delete rows with time as #1899-12-30 00:00:00#

  temp.mat=final.dat
  ###################################################
  #time.char<-as.POSIXlt(record.getup.time[ll]*24*60*60, origin = ISOdatetime(1899,12,30,0,0,0))
  hour.char<-as.numeric(format(as.POSIXlt(temp.mat$date.time*24*60*60, origin = ISOdatetime(1899,12,30,0,0,0)),"%H"))
  ###
  temp.sed<-subset(temp.mat,temp.mat$ActivityCode==0)$Interval
  length.temp.sed<-length(temp.sed)
#   month<-as.numeric(format(time.char,"%m"))
#   day<-as.numeric(format(time.char,"%d"))
#   year<-as.numeric(format(time.char,"%Y"))
  hours.worn.total<- sum(temp.mat$Interval)/60/60
  #hours.awake<- (record.sleep.time[ll]-record.getup.time[ll])*24
  sed.hour<- sum(temp.sed) /60/60
  stand.hour<- sum(subset(temp.mat,temp.mat$ActivityCode==1)$Interval) /60/60
  step.hour<- sum(subset(temp.mat,temp.mat$ActivityCode==2)$Interval) /60/60
  num.changes.from.sed.to.non.sed<- length.temp.sed
  ######## Code update here !
  step.count.total<- 2*nrow(subset(temp.mat,temp.mat$ActivityCode==2))  ##### in the event file, one row with ActivityCode==2 means two steps
  ########
  gini.index<- gini(temp.sed)
  num.hour.over.3.METs<-  sum(temp.mat$Interval[(temp.mat$METs/temp.mat$Interval)*60*60>3])/60/60
  MET.hours<- sum(temp.mat$METs)
  #valid.day<-ifelse( (hours.worn.total<10 & hours.worn.total/hours.awake>0.8 & step.count.total>200) | (hours.worn.total>=10 & step.count.total>200 ),1,0    )
  #dayofweek<-as.numeric(format(time.char,"%w"))
  #weekday.or.weekend<- ifelse( dayofweek!=0 & dayofweek!=6,1,0)
  #table1<-c(person,group.char,www,month,day,year,hours.worn.total,hours.awake,sed.hour,stand.hour,step.hour,num.changes.from.sed.to.non.sed,step.count.total,gini.index,num.hour.over.3.METs,MET.hours,valid.day,dayofweek,weekday.or.weekend)
  table<-cbind(hours.worn.total,sed.hour,stand.hour,step.hour,num.changes.from.sed.to.non.sed,step.count.total,gini.index,num.hour.over.3.METs,MET.hours)
  colnames(table)<-c("hours.worn.total","sed.hour","stand.hour","step.hour","num.changes.from.sed.to.non.sed","step.count.total","gini.index","num.hour.over.3.METs","MET.hours")

  out=list(  temp.mat= temp.mat,temp.sed= temp.sed,length.temp.sed=length.temp.sed,hour.char=hour.char, step.count.total= step.count.total,hours.worn.total=hours.worn.total, sed.hour=sed.hour, stand.hour=stand.hour, step.hour=step.hour, num.changes.from.sed.to.non.sed=num.changes.from.sed.to.non.sed, gini.index=gini.index,num.hour.over.3.METs=num.hour.over.3.METs,MET.hours=MET.hours,table=table)

 #table1.label<-c("id","group","week","month","day","year","hours.worn.total","hours.awake","sed.hour","stand.hour","step.hour","num.changes.from.sed.to.non.sed","step.count.total","gini.index","num.hour.over.3.METs","MET.hours","valid.day","dayofweek","weekday.or.weekend")
  #num.hour.over.3.METs=num.hour.over.3.METs
  return(out)
}
