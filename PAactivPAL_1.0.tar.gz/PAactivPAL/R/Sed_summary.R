#' Physical Activity Summary--Sedentary Proportions and Percentiles
#'
#' Summarize activity measures using proportions and percentiles
#' @param final.dat cleaned final data that is between record getup time and sleep time

#' @return total.sed.time Total sedantary hour, same as PA_summary function output sed.hour
#' @return total.number.of.sed.bouts Total number of sedentary bouts. It counts the number of sedentary recordings.
#' @return mean.sed.bout.length Mean sedentary bout length. It is the average of the duration time for all sedentary activities
#' @return prop.of.sed.time.greater.20min Proportions of sedentary bout greater than 20 minutes
#' @return prop.of.sed.time.greater.60min Proportions of sedentary bout greater than 60 minutes
#' @return prop.of.sed.time.greater.120min Proportions of sedentary bout greater than 120 minutes
#' @return total.sed.time.greater.20min Total sedentary time greater than 20 minutes
#' @return total.sed.time.greater.60min Total sedentary time greater than 60 minutes
#' @return total.sed.time.greater.120min Total sedentary time greater than 120 minutes
#' @return percentile.sed.time.5  5\% percentile of sedentary time
#' @return percentile.sed.time.25 25\% percentile of sedentary time
#' @return percentile.sed.time.50 50\% percentile of sedentary time
#' @return percentile.sed.time.75 75\% percentile of sedentary time
#' @return percentile.sed.time.95 95\% percentile of sedentary time
#' @return alpha.sed alpha of sendataty time, see details.
#' @return gini.index.sed  Gini index of sedantary, same as PA_summary function output gini.index
#' @return prop.sed.time.6.12 Proportions of sedentary time between 6:00-12:00
#' @return prop.sed.time.12.18 Proportions of sedentary time between 12:00-18:00
#' @return prop.sed.time.18.22 Proportions of sedentary time between 18:00-22:00
#' @details Proportions of sedentary bout greater than 20/60/120 minutes is the ratio of the number of sedentary bouts greater than 20/60/120 minutes to the total number of sedentary recordings.
#' @details Total sedentary time greater than 20/60/120 minutes is the summation of the sedentary durations which are greater than 20/60/120 minutes.
#' @details To calculate 5\%/25\%/.../95\% percentile of sedentary time, all of the recorded sedentary durations are listed and R function \emph{quantile} is used to find the percentiles.
#' @details  alpha.sed is defined by \code{1+1/M}, where \code{M} is the average of \code{log(sedentary bout length /minimum sedentary bout length)}.
#' @details Proportions of sedentary time between 6:00-12:00/12:00-18:00/18:00-22:00 is the ratio of the sedentary durations to the total activity durations between 6:00-12:00/12:00-18:00/18:00-22:00.


#' @examples  data(sampledata);sed_summary(sampledata)
#' @export

sed_summary=function(final.dat)

{library(reldist)

  dat=final.dat
  if(is.numeric(dat$Time)==F) ####if  is.numeric(dat$Time)==F, we need further modification of time in next step
  {
    ee<-as.character(dat$Time)
    max.length<-max(nchar(ee))
    ee[nchar(ee)!=max.length]<-"#1899-12-30 00:00:00#"
    #### use character type, may not be good
    ee.new<- (as.numeric( as.POSIXlt( substr(ee, 2, max.length-1 )  )    )+2209190400)/24/60/60
    #### use interval type, this is the best
    start.ee<-  min(which(dat[,2]>0))-1
    if (start.ee>1)
    {
      ee.new.int.type <-c( ee.new[1:((start.ee)-1)],ee.new[start.ee]+(dat$DataCount[start.ee:nrow(dat)]/10/24/60/60)  )
    }else
    {    ee.new.int.type <-ee.new[start.ee]+(dat$DataCount[start.ee:nrow(dat)]/10/24/60/60)
    } #### if interval type has large difference with character type, use character type
    int.dif.char<-which(abs(ee.new-ee.new.int.type)>0.1 )
    ee.new.int.type[int.dif.char]<-ee.new[int.dif.char]
    ####
    dat<-cbind(ee.new.int.type,dat[,2:6])
  }
  final.dat<-dat[,c(1,3,4,6)]
  colnames(final.dat)<-c("date.time","Interval","ActivityCode", "METs")
  final.dat=subset(final.dat,date.time!=0.625) #delete rows with time as #1899-12-30 00:00:00#

  temp.mat=final.dat
  hour.char<-as.numeric(format(as.POSIXlt(temp.mat$date.time*24*60*60, origin = ISOdatetime(1899,12,30,0,0,0)),"%H"))
  temp.sed<-subset(temp.mat,temp.mat$ActivityCode==0)$Interval
  sed.hour<- sum(temp.sed) /60/60
  length.temp.sed<-length(temp.sed)
  num.changes.from.sed.to.non.sed<- length.temp.sed
  total.sed.time<-sed.hour
  total.number.of.sed.bouts<-num.changes.from.sed.to.non.sed
  mean.sed.bout.length<- mean(temp.sed) /60/60
  prop.of.sed.time.greater.20min<- 100*length(temp.sed[temp.sed>20*60])/length.temp.sed
  prop.of.sed.time.greater.60min<- 100*length(temp.sed[temp.sed>60*60])/length.temp.sed
  prop.of.sed.time.greater.120min<- 100*length(temp.sed[temp.sed>120*60])/length.temp.sed

  total.sed.time.greater.20min<- sum(temp.sed[temp.sed>20*60])/60/60
  total.sed.time.greater.60min<- sum(temp.sed[temp.sed>60*60])/60/60
  total.sed.time.greater.120min<- sum(temp.sed[temp.sed>120*60])/60/60

  quantile.temp<-quantile(temp.sed, probs = c(0.05,0.25,0.5,0.75,0.95))/60/60
  percentile.sed.time.5<- quantile.temp[1]
  percentile.sed.time.25<- quantile.temp[2]
  percentile.sed.time.50<- quantile.temp[3]
  percentile.sed.time.75<- quantile.temp[4]
  percentile.sed.time.95<- quantile.temp[5]

  alpha.sed<- 1+ 1/mean(log(temp.sed/ min(temp.sed)))
  gini.index.sed<- gini(temp.sed)

  prop.sed.time.6.12<- 100*sum(subset(temp.mat,temp.mat$ActivityCode==0 & hour.char>=6 & hour.char<12)$Interval) /(sum(subset(temp.mat,hour.char>=6 & hour.char<12)$Interval)+0.0001)   ###prevent this value is zero
  prop.sed.time.12.18<- 100*sum(subset(temp.mat,temp.mat$ActivityCode==0 & hour.char>=12 & hour.char<18)$Interval) /(sum(subset(temp.mat,hour.char>=12 & hour.char<18)$Interval)+0.0001)
  prop.sed.time.18.22<- 100*sum(subset(temp.mat,temp.mat$ActivityCode==0 & hour.char>=18 & hour.char<22)$Interval) /(sum(subset(temp.mat,hour.char>=18 & hour.char<22)$Interval)+0.0001)
  table<-cbind(total.sed.time,total.number.of.sed.bouts,mean.sed.bout.length,prop.of.sed.time.greater.20min,prop.of.sed.time.greater.60min,prop.of.sed.time.greater.120min,total.sed.time.greater.20min,total.sed.time.greater.60min,total.sed.time.greater.120min,percentile.sed.time.5,percentile.sed.time.25,percentile.sed.time.50,percentile.sed.time.75,percentile.sed.time.95,alpha.sed,gini.index.sed,prop.sed.time.6.12,prop.sed.time.12.18,prop.sed.time.18.22)
 colnames(table)<-c("total.sed.time","total.number.of.sed.bouts","mean.sed.bout.length" ,"prop.of.sed.time.greater.20min","prop.of.sed.time.greater.60min","prop.of.sed.time.greater.120min","total.sed.time.greater.20min","total.sed.time.greater.60min","total.sed.time.greater.120min","percentile.sed.time.5","percentile.sed.time.25","percentile.sed.time.50","percentile.sed.time.75","percentile.sed.time.95","alpha.sed","gini.index.sed","prop.sed.time.6.12","prop.sed.time.12.18","prop.sed.time.18.22")

  out=list( total.sed.time=total.sed.time,total.number.of.sed.bouts=total.number.of.sed.bouts,mean.sed.bout.length=mean.sed.bout.length,prop.of.sed.time.greater.20min=prop.of.sed.time.greater.20min,prop.of.sed.time.greater.60min=prop.of.sed.time.greater.60min, prop.of.sed.time.greater.120min= prop.of.sed.time.greater.120min,total.sed.time.greater.20min=total.sed.time.greater.20min,total.sed.time.greater.60min=total.sed.time.greater.60min,total.sed.time.greater.120min=total.sed.time.greater.120min,percentile.sed.time.5=percentile.sed.time.5,percentile.sed.time.25=percentile.sed.time.25,percentile.sed.time.50=percentile.sed.time.50,percentile.sed.time.75=percentile.sed.time.75,percentile.sed.time.95=percentile.sed.time.95,alpha.sed=alpha.sed,gini.index.sed=gini.index.sed,prop.sed.time.6.12=prop.sed.time.6.12,prop.sed.time.12.18=prop.sed.time.12.18,prop.sed.time.18.22=prop.sed.time.18.22,table=table)
  return(out)
}
