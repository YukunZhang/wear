#' Physical Activity Summary--Activity Proportions
#'
#' Summarize sedantary, standing, and stepping activity measures
#' @param final.dat cleaned final data that is between record getup time and sleep time
#' @return perc.sedentary Proportion of sedentary
#' @return perc.stand Proportion of standing
#' @return perc.step Proportion of stepping
#' @return step.per.day  Number of steps during the given period of time
#' @return break.per.day Number of interrupting sedentary behavior during the given period of time
#' @return break.rate Rate of interrupting sedentary behavior
#' @return MET.hour METs hours
#' @examples  data(sampledata);ActProp_summary(sampledata)
#' @details  Proportion of sedentary/standing/stepping is the ratio of the total durations of sedentary/standing/step to the total worn time.
#' @details  For number of steps, the number of stepping records multiplied by 2. This is because every two steps lead to one row's record in the event files.
#' @details Number of interrupting sedentary behavior is approximated by the number of  sedentary bouts.
#' @details Rate of interrupting sedentary behavior is the ratio of the daily number of interrupting sedentary behavior to total sedentary hours.
#' @details	 METs hours is the summation of METs hours from all activity records.

#'@export
#'

ActProp_summary=function (final.dat) {
 out=PA_summary(final.dat)
  sed.hour=out$sed.hour
  stand.hour=out$stand.hour
  step.hour=out$step.hour
  hours.worn.total=out$hours.worn.total
  step.count.total=out$step.count.total
  num.changes.from.sed.to.non.sed=out$num.changes.from.sed.to.non.sed
  MET.hours=out$MET.hours
perc.sedentary<- 100*sed.hour/hours.worn.total
perc.stand<- 100*stand.hour/hours.worn.total
perc.step<- 100*step.hour/hours.worn.total
step.per.day<-step.count.total
break.per.day<-num.changes.from.sed.to.non.sed
break.rate<-break.per.day/sed.hour
MET.hour<- MET.hours

table<- cbind(perc.sedentary,perc.stand,perc.step,step.per.day,break.per.day,break.rate,MET.hour)
colnames(table)<- c("perc.sedentary","perc.stand","perc.step","step.per.day","break.per.day","break.rate","MET.hour")
out=list(  perc.sedentary=perc.sedentary,perc.stand=perc.stand,perc.step=perc.step,step.per.day=step.per.day,break.per.day=break.per.day,break.rate=break.rate,MET.hour=MET.hour,table=table)
return(out)
}
